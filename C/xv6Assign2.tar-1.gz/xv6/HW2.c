//#include "param.h"
#include "fcntl.h"
#include "types.h"
#include "stat.h"
#include "user.h"



int main(void){

/*
This program uses "fcntl.h to use the file controls(O_CREATE|O_RDWR)", "types.h", "stat.h", "user.h".  The programs functionality is to print my name(James Painter), Create and open file(tom.txt), Write to the file using a file discriptor(1,2,3,4). Then it closes the fildescriptor and shows what was written to the file by using the program cat. 


The system calls used in this program are: printf(1,"");, open("file", O_CREATE|O_RDWR);,
write(file descriptor, "string written to file", terminating character);, close(file descriptor); close(0);== close process, exec("looks through array", array"); 
*/	
	printf(1,"James Painter\n");


	char *argv[2];
	argv[0] ="cat";
	argv[1]=0;


	int fd;
	fd = open("tom.txt", O_CREATE|O_RDWR);
	write(fd, "1, 2, 3, 4\n", 12);
	close(fd);  
	
	close(0);
	open("tom.txt", O_RDONLY);
	exec("cat", argv);

	exit();  



}
