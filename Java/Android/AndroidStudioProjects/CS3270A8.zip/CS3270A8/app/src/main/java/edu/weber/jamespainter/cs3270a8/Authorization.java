package edu.weber.jamespainter.cs3270a8;

/**
 * Created by JamesPainter on 3/12/2017.
 */

public class Authorization {

    final static String AUTH_TOKEN = "";

}
